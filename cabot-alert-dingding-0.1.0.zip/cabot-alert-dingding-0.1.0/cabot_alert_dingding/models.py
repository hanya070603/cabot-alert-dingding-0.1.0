from django.db import models

from cabot.cabotapp.alert import AlertPlugin
from cabot.cabotapp.alert import AlertPluginUserData

import requests
import json


class DingdingkAlert(AlertPlugin):
    name = "dingding"
    slug = "cabot_alert_dingding"
    author = "hanliangfeng"

    def send_alert(self, service, users, duty_officers):
        #payload = {
        #    'service': service.name,
        #    'status': service.overall_status,
        #    'old_status': service.old_overall_status,
        #}
        payload = {
            "msgtype": "text", 
            "text": {
                "content": service.name + "  " + service.overall_status + "  " + service.old_overall_status
            }, 
            "at": {
                "atMobiles": [
                  service.name
                ], 
                "isAtAll": true
            }
        }
        dingding_urls = [u.dingding_url for u in DingdingAlertUserData.objects.filter(user__user__in=users)]
        headers = {'Content-Type': 'application/json'}
        for url in dingding_urls:
            requests.post(
                url,
                data=json.dumps(payload),
                headers=headers
            )
        return True


class DingdingAlertUserData(AlertPluginUserData):
    name = "dingding Plugin"
    dingding_url = models.URLField(max_length=200, blank=True)
