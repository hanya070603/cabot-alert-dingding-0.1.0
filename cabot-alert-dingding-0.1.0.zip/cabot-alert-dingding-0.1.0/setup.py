#!/usr/bin/env python

from setuptools import setup, find_packages
import os
import sys

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
if sys.version_info[0] < 3:
    with open(os.path.join(BASE_DIR, 'README.rst')) as f:
        long_description = f.read()
else:
    with open(os.path.join(BASE_DIR, 'README.rst'), encoding='utf-8') as f:
        long_description = f.read()

setup(
    name='cabot-alert-dingding',
    version='0.1.0',
    description='A Dingding plugin for Cabot',
    long_description=long_description,
    author='hanliangfeng',
    author_email='18620887738@163.com',
    url='https://github.com/hanya070603/cabot-alert-dingding-0.1.0',
    packages=find_packages(),
    download_url = 'https://github.com/hanya070603/cabot-alert-dingding-0.1.0',
    bugtrack_url = "https://github.com/hanya070603/cabot-alert-dingding-0.1.0",
    keywords = ['cabot', 'dingding', 'status check'],
)
